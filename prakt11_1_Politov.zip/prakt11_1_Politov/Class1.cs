﻿using System;

public class Student
{
    public	string name;
	public double rost;
	public double ves;
	public void SetEat
    {

    }
	public double GetEat(double vs)
    {
		ves = vs;
		return ves;
    }
}
