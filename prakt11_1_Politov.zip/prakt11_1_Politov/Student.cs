﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prakt11_1
{
    
    class Student
    {
        public string name;
        public double rost;
        private double ves;
        public double food;
        public Student(double sves)
        {
            ves = sves;
        }
        public void sStudent(double sves)
        {
            ves = sves;
        }
        public void SetEat(double eda)
        {
            if(eda >= 10)
            {
                rost -= 2;
                ves += 0.5 * (eda * 1000 - 1800) / 1000;
            }
            else if(eda >=5)
            {
                rost -= 1;
                ves += 0.7 * (eda * 1000 - 1600) / 1000;
            }
            else
            {
                ves += eda;
            }
        } 
        public double GetEat()
        {
            
            return ves;
        }
    }
}
